a = 9
b =  8
c = a+b
print c