import ConfigParser

config = ConfigParser.ConfigParser()
config.readfp(open('limits.cfg'))

